var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/@netlify/blobs/dist/chunk-XR3MUBBK.js
var NF_ERROR, NF_REQUEST_ID, BlobsInternalError, collectIterator, base64Decode, base64Encode, getEnvironment, getEnvironmentContext, setEnvironmentContext, MissingBlobsEnvironmentError, BASE64_PREFIX, METADATA_HEADER_INTERNAL, METADATA_HEADER_EXTERNAL, METADATA_MAX_SIZE, encodeMetadata, decodeMetadata, getMetadataFromResponse, BlobsConsistencyError, REGION_AUTO, regions, isValidRegion, InvalidBlobsRegionError, DEFAULT_RETRY_DELAY, MIN_RETRY_DELAY, MAX_RETRY, RATE_LIMIT_HEADER, fetchAndRetry, getDelay, sleep, SIGNED_URL_ACCEPT_HEADER, Client, getClientOptions;
var init_chunk_XR3MUBBK = __esm({
  "node_modules/@netlify/blobs/dist/chunk-XR3MUBBK.js"() {
    NF_ERROR = "x-nf-error";
    NF_REQUEST_ID = "x-nf-request-id";
    BlobsInternalError = class extends Error {
      constructor(res) {
        let details = res.headers.get(NF_ERROR) || `${res.status} status code`;
        if (res.headers.has(NF_REQUEST_ID)) {
          details += `, ID: ${res.headers.get(NF_REQUEST_ID)}`;
        }
        super(`Netlify Blobs has generated an internal error (${details})`);
        this.name = "BlobsInternalError";
      }
    };
    collectIterator = async (iterator) => {
      const result = [];
      for await (const item of iterator) {
        result.push(item);
      }
      return result;
    };
    base64Decode = (input) => {
      const { Buffer: Buffer2 } = globalThis;
      if (Buffer2) {
        return Buffer2.from(input, "base64").toString();
      }
      return atob(input);
    };
    base64Encode = (input) => {
      const { Buffer: Buffer2 } = globalThis;
      if (Buffer2) {
        return Buffer2.from(input).toString("base64");
      }
      return btoa(input);
    };
    getEnvironment = () => {
      const { Deno, Netlify, process: process2 } = globalThis;
      return Netlify?.env ?? Deno?.env ?? {
        delete: (key) => delete process2?.env[key],
        get: (key) => process2?.env[key],
        has: (key) => Boolean(process2?.env[key]),
        set: (key, value) => {
          if (process2?.env) {
            process2.env[key] = value;
          }
        },
        toObject: () => process2?.env ?? {}
      };
    };
    getEnvironmentContext = () => {
      const context = globalThis.netlifyBlobsContext || getEnvironment().get("NETLIFY_BLOBS_CONTEXT");
      if (typeof context !== "string" || !context) {
        return {};
      }
      const data = base64Decode(context);
      try {
        return JSON.parse(data);
      } catch {
      }
      return {};
    };
    setEnvironmentContext = (context) => {
      const encodedContext = base64Encode(JSON.stringify(context));
      getEnvironment().set("NETLIFY_BLOBS_CONTEXT", encodedContext);
    };
    MissingBlobsEnvironmentError = class extends Error {
      constructor(requiredProperties) {
        super(
          `The environment has not been configured to use Netlify Blobs. To use it manually, supply the following properties when creating a store: ${requiredProperties.join(
            ", "
          )}`
        );
        this.name = "MissingBlobsEnvironmentError";
      }
    };
    BASE64_PREFIX = "b64;";
    METADATA_HEADER_INTERNAL = "x-amz-meta-user";
    METADATA_HEADER_EXTERNAL = "netlify-blobs-metadata";
    METADATA_MAX_SIZE = 2 * 1024;
    encodeMetadata = (metadata) => {
      if (!metadata) {
        return null;
      }
      const encodedObject = base64Encode(JSON.stringify(metadata));
      const payload = `b64;${encodedObject}`;
      if (METADATA_HEADER_EXTERNAL.length + payload.length > METADATA_MAX_SIZE) {
        throw new Error("Metadata object exceeds the maximum size");
      }
      return payload;
    };
    decodeMetadata = (header) => {
      if (!header || !header.startsWith(BASE64_PREFIX)) {
        return {};
      }
      const encodedData = header.slice(BASE64_PREFIX.length);
      const decodedData = base64Decode(encodedData);
      const metadata = JSON.parse(decodedData);
      return metadata;
    };
    getMetadataFromResponse = (response) => {
      if (!response.headers) {
        return {};
      }
      const value = response.headers.get(METADATA_HEADER_EXTERNAL) || response.headers.get(METADATA_HEADER_INTERNAL);
      try {
        return decodeMetadata(value);
      } catch {
        throw new Error(
          "An internal error occurred while trying to retrieve the metadata for an entry. Please try updating to the latest version of the Netlify Blobs client."
        );
      }
    };
    BlobsConsistencyError = class extends Error {
      constructor() {
        super(
          `Netlify Blobs has failed to perform a read using strong consistency because the environment has not been configured with a 'uncachedEdgeURL' property`
        );
        this.name = "BlobsConsistencyError";
      }
    };
    REGION_AUTO = "auto";
    regions = {
      "us-east-1": true,
      "us-east-2": true,
      "eu-central-1": true,
      "ap-southeast-1": true,
      "ap-southeast-2": true
    };
    isValidRegion = (input) => Object.keys(regions).includes(input);
    InvalidBlobsRegionError = class extends Error {
      constructor(region) {
        super(
          `${region} is not a supported Netlify Blobs region. Supported values are: ${Object.keys(regions).join(", ")}.`
        );
        this.name = "InvalidBlobsRegionError";
      }
    };
    DEFAULT_RETRY_DELAY = getEnvironment().get("NODE_ENV") === "test" ? 1 : 5e3;
    MIN_RETRY_DELAY = 1e3;
    MAX_RETRY = 5;
    RATE_LIMIT_HEADER = "X-RateLimit-Reset";
    fetchAndRetry = async (fetch2, url, options, attemptsLeft = MAX_RETRY) => {
      try {
        const res = await fetch2(url, options);
        if (attemptsLeft > 0 && (res.status === 429 || res.status >= 500)) {
          const delay = getDelay(res.headers.get(RATE_LIMIT_HEADER));
          await sleep(delay);
          return fetchAndRetry(fetch2, url, options, attemptsLeft - 1);
        }
        return res;
      } catch (error) {
        if (attemptsLeft === 0) {
          throw error;
        }
        const delay = getDelay();
        await sleep(delay);
        return fetchAndRetry(fetch2, url, options, attemptsLeft - 1);
      }
    };
    getDelay = (rateLimitReset) => {
      if (!rateLimitReset) {
        return DEFAULT_RETRY_DELAY;
      }
      return Math.max(Number(rateLimitReset) * 1e3 - Date.now(), MIN_RETRY_DELAY);
    };
    sleep = (ms) => new Promise((resolve) => {
      setTimeout(resolve, ms);
    });
    SIGNED_URL_ACCEPT_HEADER = "application/json;type=signed-url";
    Client = class {
      constructor({ apiURL, consistency, edgeURL, fetch: fetch2, region, siteID, token, uncachedEdgeURL }) {
        this.apiURL = apiURL;
        this.consistency = consistency ?? "eventual";
        this.edgeURL = edgeURL;
        this.fetch = fetch2 ?? globalThis.fetch;
        this.region = region;
        this.siteID = siteID;
        this.token = token;
        this.uncachedEdgeURL = uncachedEdgeURL;
        if (!this.fetch) {
          throw new Error(
            "Netlify Blobs could not find a `fetch` client in the global scope. You can either update your runtime to a version that includes `fetch` (like Node.js 18.0.0 or above), or you can supply your own implementation using the `fetch` property."
          );
        }
      }
      async getFinalRequest({
        consistency: opConsistency,
        key,
        metadata,
        method,
        parameters = {},
        storeName
      }) {
        const encodedMetadata = encodeMetadata(metadata);
        const consistency = opConsistency ?? this.consistency;
        let urlPath = `/${this.siteID}`;
        if (storeName) {
          urlPath += `/${storeName}`;
        }
        if (key) {
          urlPath += `/${key}`;
        }
        if (this.edgeURL) {
          if (consistency === "strong" && !this.uncachedEdgeURL) {
            throw new BlobsConsistencyError();
          }
          const headers = {
            authorization: `Bearer ${this.token}`
          };
          if (encodedMetadata) {
            headers[METADATA_HEADER_INTERNAL] = encodedMetadata;
          }
          if (this.region) {
            urlPath = `/region:${this.region}${urlPath}`;
          }
          const url2 = new URL(urlPath, consistency === "strong" ? this.uncachedEdgeURL : this.edgeURL);
          for (const key2 in parameters) {
            url2.searchParams.set(key2, parameters[key2]);
          }
          return {
            headers,
            url: url2.toString()
          };
        }
        const apiHeaders = { authorization: `Bearer ${this.token}` };
        const url = new URL(`/api/v1/blobs${urlPath}`, this.apiURL ?? "https://api.netlify.com");
        for (const key2 in parameters) {
          url.searchParams.set(key2, parameters[key2]);
        }
        if (this.region) {
          url.searchParams.set("region", this.region);
        }
        if (storeName === void 0 || key === void 0) {
          return {
            headers: apiHeaders,
            url: url.toString()
          };
        }
        if (encodedMetadata) {
          apiHeaders[METADATA_HEADER_EXTERNAL] = encodedMetadata;
        }
        if (method === "head" || method === "delete") {
          return {
            headers: apiHeaders,
            url: url.toString()
          };
        }
        const res = await this.fetch(url.toString(), {
          headers: { ...apiHeaders, accept: SIGNED_URL_ACCEPT_HEADER },
          method
        });
        if (res.status !== 200) {
          throw new BlobsInternalError(res);
        }
        const { url: signedURL } = await res.json();
        const userHeaders = encodedMetadata ? { [METADATA_HEADER_INTERNAL]: encodedMetadata } : void 0;
        return {
          headers: userHeaders,
          url: signedURL
        };
      }
      async makeRequest({
        body,
        consistency,
        headers: extraHeaders,
        key,
        metadata,
        method,
        parameters,
        storeName
      }) {
        const { headers: baseHeaders = {}, url } = await this.getFinalRequest({
          consistency,
          key,
          metadata,
          method,
          parameters,
          storeName
        });
        const headers = {
          ...baseHeaders,
          ...extraHeaders
        };
        if (method === "put") {
          headers["cache-control"] = "max-age=0, stale-while-revalidate=60";
        }
        const options = {
          body,
          headers,
          method
        };
        if (body instanceof ReadableStream) {
          options.duplex = "half";
        }
        return fetchAndRetry(this.fetch, url, options);
      }
    };
    getClientOptions = (options, contextOverride) => {
      const context = contextOverride ?? getEnvironmentContext();
      const siteID = context.siteID ?? options.siteID;
      const token = context.token ?? options.token;
      if (!siteID || !token) {
        throw new MissingBlobsEnvironmentError(["siteID", "token"]);
      }
      if (options.region !== void 0 && !isValidRegion(options.region)) {
        throw new InvalidBlobsRegionError(options.region);
      }
      const clientOptions = {
        apiURL: context.apiURL ?? options.apiURL,
        consistency: options.consistency,
        edgeURL: context.edgeURL ?? options.edgeURL,
        fetch: options.fetch,
        region: options.region,
        siteID,
        token,
        uncachedEdgeURL: context.uncachedEdgeURL ?? options.uncachedEdgeURL
      };
      return clientOptions;
    };
  }
});

// node_modules/@netlify/blobs/dist/main.js
var main_exports = {};
__export(main_exports, {
  connectLambda: () => connectLambda,
  getDeployStore: () => getDeployStore,
  getStore: () => getStore,
  listStores: () => listStores,
  setEnvironmentContext: () => setEnvironmentContext
});
function listStores(options = {}) {
  const context = getEnvironmentContext();
  const clientOptions = getClientOptions(options, context);
  const client = new Client(clientOptions);
  const iterator = getListIterator(client, SITE_STORE_PREFIX);
  if (options.paginate) {
    return iterator;
  }
  return collectIterator(iterator).then((results) => ({ stores: results.flatMap((page) => page.stores) }));
}
var connectLambda, DEPLOY_STORE_PREFIX, LEGACY_STORE_INTERNAL_PREFIX, SITE_STORE_PREFIX, Store, getDeployStore, getStore, formatListStoreResponse, getListIterator;
var init_main = __esm({
  "node_modules/@netlify/blobs/dist/main.js"() {
    init_chunk_XR3MUBBK();
    connectLambda = (event) => {
      const rawData = base64Decode(event.blobs);
      const data = JSON.parse(rawData);
      const environmentContext = {
        deployID: event.headers["x-nf-deploy-id"],
        edgeURL: data.url,
        siteID: event.headers["x-nf-site-id"],
        token: data.token
      };
      setEnvironmentContext(environmentContext);
    };
    DEPLOY_STORE_PREFIX = "deploy:";
    LEGACY_STORE_INTERNAL_PREFIX = "netlify-internal/legacy-namespace/";
    SITE_STORE_PREFIX = "site:";
    Store = class _Store {
      constructor(options) {
        this.client = options.client;
        if ("deployID" in options) {
          _Store.validateDeployID(options.deployID);
          let name = DEPLOY_STORE_PREFIX + options.deployID;
          if (options.name) {
            name += `:${options.name}`;
          }
          this.name = name;
        } else if (options.name.startsWith(LEGACY_STORE_INTERNAL_PREFIX)) {
          const storeName = options.name.slice(LEGACY_STORE_INTERNAL_PREFIX.length);
          _Store.validateStoreName(storeName);
          this.name = storeName;
        } else {
          _Store.validateStoreName(options.name);
          this.name = SITE_STORE_PREFIX + options.name;
        }
      }
      async delete(key) {
        const res = await this.client.makeRequest({ key, method: "delete", storeName: this.name });
        if (![200, 204, 404].includes(res.status)) {
          throw new BlobsInternalError(res);
        }
      }
      async get(key, options) {
        const { consistency, type } = options ?? {};
        const res = await this.client.makeRequest({ consistency, key, method: "get", storeName: this.name });
        if (res.status === 404) {
          return null;
        }
        if (res.status !== 200) {
          throw new BlobsInternalError(res);
        }
        if (type === void 0 || type === "text") {
          return res.text();
        }
        if (type === "arrayBuffer") {
          return res.arrayBuffer();
        }
        if (type === "blob") {
          return res.blob();
        }
        if (type === "json") {
          return res.json();
        }
        if (type === "stream") {
          return res.body;
        }
        throw new BlobsInternalError(res);
      }
      async getMetadata(key, { consistency } = {}) {
        const res = await this.client.makeRequest({ consistency, key, method: "head", storeName: this.name });
        if (res.status === 404) {
          return null;
        }
        if (res.status !== 200 && res.status !== 304) {
          throw new BlobsInternalError(res);
        }
        const etag = res?.headers.get("etag") ?? void 0;
        const metadata = getMetadataFromResponse(res);
        const result = {
          etag,
          metadata
        };
        return result;
      }
      async getWithMetadata(key, options) {
        const { consistency, etag: requestETag, type } = options ?? {};
        const headers = requestETag ? { "if-none-match": requestETag } : void 0;
        const res = await this.client.makeRequest({
          consistency,
          headers,
          key,
          method: "get",
          storeName: this.name
        });
        if (res.status === 404) {
          return null;
        }
        if (res.status !== 200 && res.status !== 304) {
          throw new BlobsInternalError(res);
        }
        const responseETag = res?.headers.get("etag") ?? void 0;
        const metadata = getMetadataFromResponse(res);
        const result = {
          etag: responseETag,
          metadata
        };
        if (res.status === 304 && requestETag) {
          return { data: null, ...result };
        }
        if (type === void 0 || type === "text") {
          return { data: await res.text(), ...result };
        }
        if (type === "arrayBuffer") {
          return { data: await res.arrayBuffer(), ...result };
        }
        if (type === "blob") {
          return { data: await res.blob(), ...result };
        }
        if (type === "json") {
          return { data: await res.json(), ...result };
        }
        if (type === "stream") {
          return { data: res.body, ...result };
        }
        throw new Error(`Invalid 'type' property: ${type}. Expected: arrayBuffer, blob, json, stream, or text.`);
      }
      list(options = {}) {
        const iterator = this.getListIterator(options);
        if (options.paginate) {
          return iterator;
        }
        return collectIterator(iterator).then(
          (items) => items.reduce(
            (acc, item) => ({
              blobs: [...acc.blobs, ...item.blobs],
              directories: [...acc.directories, ...item.directories]
            }),
            { blobs: [], directories: [] }
          )
        );
      }
      async set(key, data, { metadata } = {}) {
        _Store.validateKey(key);
        const res = await this.client.makeRequest({
          body: data,
          key,
          metadata,
          method: "put",
          storeName: this.name
        });
        if (res.status !== 200) {
          throw new BlobsInternalError(res);
        }
      }
      async setJSON(key, data, { metadata } = {}) {
        _Store.validateKey(key);
        const payload = JSON.stringify(data);
        const headers = {
          "content-type": "application/json"
        };
        const res = await this.client.makeRequest({
          body: payload,
          headers,
          key,
          metadata,
          method: "put",
          storeName: this.name
        });
        if (res.status !== 200) {
          throw new BlobsInternalError(res);
        }
      }
      static formatListResultBlob(result) {
        if (!result.key) {
          return null;
        }
        return {
          etag: result.etag,
          key: result.key
        };
      }
      static validateKey(key) {
        if (key === "") {
          throw new Error("Blob key must not be empty.");
        }
        if (key.startsWith("/") || key.startsWith("%2F")) {
          throw new Error("Blob key must not start with forward slash (/).");
        }
        if (new TextEncoder().encode(key).length > 600) {
          throw new Error(
            "Blob key must be a sequence of Unicode characters whose UTF-8 encoding is at most 600 bytes long."
          );
        }
      }
      static validateDeployID(deployID) {
        if (!/^\w{1,24}$/.test(deployID)) {
          throw new Error(`'${deployID}' is not a valid Netlify deploy ID.`);
        }
      }
      static validateStoreName(name) {
        if (name.includes("/") || name.includes("%2F")) {
          throw new Error("Store name must not contain forward slashes (/).");
        }
        if (new TextEncoder().encode(name).length > 64) {
          throw new Error(
            "Store name must be a sequence of Unicode characters whose UTF-8 encoding is at most 64 bytes long."
          );
        }
      }
      getListIterator(options) {
        const { client, name: storeName } = this;
        const parameters = {};
        if (options?.prefix) {
          parameters.prefix = options.prefix;
        }
        if (options?.directories) {
          parameters.directories = "true";
        }
        return {
          [Symbol.asyncIterator]() {
            let currentCursor = null;
            let done = false;
            return {
              async next() {
                if (done) {
                  return { done: true, value: void 0 };
                }
                const nextParameters = { ...parameters };
                if (currentCursor !== null) {
                  nextParameters.cursor = currentCursor;
                }
                const res = await client.makeRequest({
                  method: "get",
                  parameters: nextParameters,
                  storeName
                });
                let blobs = [];
                let directories = [];
                if (![200, 204, 404].includes(res.status)) {
                  throw new BlobsInternalError(res);
                }
                if (res.status === 404) {
                  done = true;
                } else {
                  const page = await res.json();
                  if (page.next_cursor) {
                    currentCursor = page.next_cursor;
                  } else {
                    done = true;
                  }
                  blobs = (page.blobs ?? []).map(_Store.formatListResultBlob).filter(Boolean);
                  directories = page.directories ?? [];
                }
                return {
                  done: false,
                  value: {
                    blobs,
                    directories
                  }
                };
              }
            };
          }
        };
      }
    };
    getDeployStore = (input = {}) => {
      const context = getEnvironmentContext();
      const options = typeof input === "string" ? { name: input } : input;
      const deployID = options.deployID ?? context.deployID;
      if (!deployID) {
        throw new MissingBlobsEnvironmentError(["deployID"]);
      }
      const clientOptions = getClientOptions(options, context);
      if (!clientOptions.region) {
        if (clientOptions.edgeURL || clientOptions.uncachedEdgeURL) {
          if (!context.primaryRegion) {
            throw new Error(
              "When accessing a deploy store, the Netlify Blobs client needs to be configured with a region, and one was not found in the environment. To manually set the region, set the `region` property in the `getDeployStore` options. If you are using the Netlify CLI, you may have an outdated version; run `npm install -g netlify-cli@latest` to update and try again."
            );
          }
          clientOptions.region = context.primaryRegion;
        } else {
          clientOptions.region = REGION_AUTO;
        }
      }
      const client = new Client(clientOptions);
      return new Store({ client, deployID, name: options.name });
    };
    getStore = (input) => {
      if (typeof input === "string") {
        const clientOptions = getClientOptions({});
        const client = new Client(clientOptions);
        return new Store({ client, name: input });
      }
      if (typeof input?.name === "string" && typeof input?.siteID === "string" && typeof input?.token === "string") {
        const { name, siteID, token } = input;
        const clientOptions = getClientOptions(input, { siteID, token });
        if (!name || !siteID || !token) {
          throw new MissingBlobsEnvironmentError(["name", "siteID", "token"]);
        }
        const client = new Client(clientOptions);
        return new Store({ client, name });
      }
      if (typeof input?.name === "string") {
        const { name } = input;
        const clientOptions = getClientOptions(input);
        if (!name) {
          throw new MissingBlobsEnvironmentError(["name"]);
        }
        const client = new Client(clientOptions);
        return new Store({ client, name });
      }
      if (typeof input?.deployID === "string") {
        const clientOptions = getClientOptions(input);
        const { deployID } = input;
        if (!deployID) {
          throw new MissingBlobsEnvironmentError(["deployID"]);
        }
        const client = new Client(clientOptions);
        return new Store({ client, deployID });
      }
      throw new Error(
        "The `getStore` method requires the name of the store as a string or as the `name` property of an options object"
      );
    };
    formatListStoreResponse = (stores) => stores.filter((store) => !store.startsWith(DEPLOY_STORE_PREFIX)).map((store) => store.startsWith(SITE_STORE_PREFIX) ? store.slice(SITE_STORE_PREFIX.length) : store);
    getListIterator = (client, prefix) => {
      const parameters = {
        prefix
      };
      return {
        [Symbol.asyncIterator]() {
          let currentCursor = null;
          let done = false;
          return {
            async next() {
              if (done) {
                return { done: true, value: void 0 };
              }
              const nextParameters = { ...parameters };
              if (currentCursor !== null) {
                nextParameters.cursor = currentCursor;
              }
              const res = await client.makeRequest({
                method: "get",
                parameters: nextParameters
              });
              if (res.status === 404) {
                return { done: true, value: void 0 };
              }
              const page = await res.json();
              if (page.next_cursor) {
                currentCursor = page.next_cursor;
              } else {
                done = true;
              }
              return {
                done: false,
                value: {
                  ...page,
                  stores: formatListStoreResponse(page.stores)
                }
              };
            }
          };
        }
      };
    };
  }
});

// netlify/functions/nekox.mjs
var nekox_exports = {};
__export(nekox_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(nekox_exports);
var ANILIST = "https://graphql.anilist.co";
var json = (body, status = 200) => ({
  statusCode: status,
  headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
  body: JSON.stringify(body)
});
async function gql(query, variables = {}) {
  const r = await fetch(ANILIST, {
    method: "POST",
    headers: { "Content-Type": "application/json", "Accept": "application/json" },
    body: JSON.stringify({ query, variables })
  });
  return r.json();
}
var PAGE = `query($page:Int,$per:Int,$sort:[MediaSort],$search:String,$genre:[String]){
  Page(page:$page,perPage:$per){
    media(sort:$sort,search:$search,genre_in:$genre,type:ANIME){
      id title{romaji english native} coverImage{extraLarge large}
      episodes status format seasonYear description nextAiringEpisode{episode}
      siteUrl genres studios(isMain:true){edges{node{name}}} startDate{year}
    }
  }
}`;
var SCHEDULE = `query($page:Int,$per:Int){
  Page(page:$page,perPage:$per){
    airingSchedules(sort:TIME,notYetAired:true){
      episode airingAt media{title{romaji english} coverImage{large} id}
    }
  }
}`;
var INFO = `query($id:Int){
  Media(id:$id,type:ANIME){
    id title{romaji english native} coverImage{extraLarge large}
    episodes status format seasonYear description nextAiringEpisode{episode}
    siteUrl genres studios(isMain:true){edges{node{name}}} startDate{year}
  }
}`;
var handler = async (event) => {
  try {
    const route = event.path.replace(/^\/api\/anime/, "").replace(/^\/\.netlify\/functions\/nekox/, "") || "/";
    const params = event.queryStringParameters || {};
    const page = parseInt(params.page || "1", 10);
    const per = Math.min(parseInt(params.per_page || "30", 10), 50);
    const list = async (sort, extra = {}) => {
      const r = await gql(PAGE, { page, per, sort, ...extra });
      return json({ results: r?.data?.Page?.media || [] });
    };
    if (route === "/spotlight" || route === "/trending") return list(["TRENDING_DESC"]);
    if (route === "/popular") return list(["POPULARITY_DESC"]);
    if (route === "/recent") return list(["UPDATED_AT_DESC"]);
    if (route === "/search") return list(["SEARCH_MATCH"], { search: params.query || "" });
    if (route === "/filter") {
      const genre = params.genre;
      return list(["POPULARITY_DESC"], genre ? { genre: [genre] } : {});
    }
    if (route === "/schedule") {
      const r = await gql(SCHEDULE, { page, per });
      return json({ results: r?.data?.Page?.airingSchedules || [] });
    }
    const m = route.match(/^\/info\/(\d+)$/);
    if (m) {
      const r = await gql(INFO, { id: +m[1] });
      return json({ result: r?.data?.Media || null });
    }
    const e = route.match(/^\/episodes\/(\d+)$/);
    if (e) {
      const r = await gql(INFO, { id: +e[1] });
      const n = r?.data?.Media?.episodes || r?.data?.Media?.nextAiringEpisode?.episode || 0;
      const eps = Array.from({ length: n }, (_, i) => ({
        id: `${e[1]}:${i + 1}`,
        number: i + 1,
        title: `Episode ${i + 1}`
      }));
      return json({ results: eps });
    }
    const ZG_INDEX = "https://raw.githubusercontent.com/Spyou/zangetsu-providers/main/index.json";
    const ZG_BASE = "https://raw.githubusercontent.com/Spyou/zangetsu-providers/main/";
    const vm = await import("vm");
    const codeCache = {};
    const loadProvider = async (id) => {
      if (codeCache[id]) return codeCache[id];
      const code = await (await fetch(`${ZG_BASE}providers/${id}.js`)).text();
      const zfetch = async (u, o = {}) => {
        const r = await fetch(u, o);
        return { status: r.status, headers: Object.fromEntries(r.headers), body: await r.text() };
      };
      const ctx = vm.createContext({
        fetch: zfetch,
        console,
        setTimeout,
        clearTimeout,
        setInterval,
        clearInterval,
        queueMicrotask,
        Buffer,
        URL,
        URLSearchParams,
        TextEncoder,
        TextDecoder,
        atob: (s) => Buffer.from(s, "base64").toString("binary"),
        btoa: (s) => Buffer.from(s, "binary").toString("base64"),
        crypto,
        Uint8Array,
        Promise,
        ArrayBuffer,
        DataView,
        // Zangetsu host-API helpers the providers expect as globals.
        htmlText: (s) => String(s || "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n)).replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCharCode(parseInt(n, 16))).replace(/&nbsp;/g, " "),
        base64ToBytes: (s) => Array.from(Buffer.from(String(s || ""), "base64")),
        absUrl: (href, base) => {
          try {
            return new URL(href, base || "https://localhost/").href;
          } catch {
            return href;
          }
        }
      });
      const api = vm.runInContext(
        `(function(){${code}; return {getInfo, search, getDetail, getEpisodes, getVideoSources};})()`,
        ctx,
        { timeout: 2e4 }
      );
      codeCache[id] = api;
      return api;
    };
    const zgStreams = async (id, title, ep) => {
      const tag = `zg-${id}`;
      try {
        const p = await loadProvider(id);
        const hits = await p.search(title, 1, {});
        const first = Array.isArray(hits) ? hits[0] : hits?.results?.[0] || hits?.items?.[0];
        if (!first) {
          errs.push(`${tag}: search empty`);
          return null;
        }
        const detail = await p.getDetail(first.url || first.id, {});
        const eps = detail?.episodes || await p.getEpisodes?.(first.url, {}) || [];
        const target = eps[ep - 1] || eps[0];
        if (!target) {
          errs.push(`${tag}: no ep ${ep} of ${eps.length}`);
          return null;
        }
        const srcs = await p.getVideoSources(target.url || target.id || target);
        const streams = (srcs?.streams || srcs?.sources || (Array.isArray(srcs) ? srcs : [])).map((s) => ({
          url: s.url || s.file,
          type: s.type || (s.url?.includes(".m3u8") ? "hls" : "mp4"),
          referer: s.referer || s.headers?.Referer || "",
          quality: s.quality || "auto"
        })).filter((s) => s.url);
        if (!streams.length) errs.push(`${tag}: getVideoSources empty (keys ${typeof srcs === "object" && srcs ? Object.keys(srcs).join(",") : typeof srcs})`);
        return streams.length ? { streams, provider: tag } : null;
      } catch (e2) {
        errs.push(`${tag}: ${String(e2?.message || e2)}`);
        return null;
      }
    };
    const errs = [];
    const providers = [
      async (title, ep) => zgStreams("hianime", title, ep),
      async (title, ep) => zgStreams("anikoto", title, ep),
      async (title, ep) => zgStreams("fourkhdhub", title, ep)
    ];
    const ex = route.match(/^\/extract\/(\d+)$/);
    if (ex) {
      const info = (await gql(INFO, { id: +ex[1] }))?.data?.Media;
      const title = info?.title?.english || info?.title?.romaji || "";
      const ep = parseInt((params.e || "1").split(":").pop() || "1", 10);
      for (const p of providers) {
        try {
          const r = await p(title, ep);
          if (r?.streams?.length) return json({ ssub: r, sdub: r, provider: r.provider });
          errs.push(`${p.name || "provider"}: empty`);
        } catch (e2) {
          errs.push(String(e2?.message || e2));
        }
      }
      return json({ error: "No provider returned streams", title, ep, errs }, 404);
    }
    const px = route.match(/^\/proxy\/(m3u8|segment)$/);
    if (px) {
      const target = params.url;
      if (!target || !/^https?:\/\//.test(target)) return json({ error: "Bad url" }, 400);
      const r = await fetch(target, { headers: { Referer: params.referer || "", "User-Agent": "Mozilla/5.0" } });
      const buf = Buffer.from(await r.arrayBuffer());
      return {
        statusCode: r.status,
        headers: { "Content-Type": r.headers.get("content-type") || "application/octet-stream", "Access-Control-Allow-Origin": "*" },
        body: buf.toString("base64"),
        isBase64Encoded: true
      };
    }
    if (route === "/providers") {
      return json({
        metadata: [
          { id: "hosted", kind: "rest", base: "/api/anime" },
          { id: "anilist", kind: "graphql", base: "https://graphql.anilist.co" },
          { id: "kitsu", kind: "rest", base: "https://kitsu.io/api/edge" },
          { id: "jikan", kind: "rest", base: "https://api.jikan.moe/v4" }
        ],
        streams: [
          { id: "hosted-extract", kind: "rest", base: "/api/anime/extract" },
          { id: "hianime", kind: "zg-provider", repo: ZG_INDEX },
          { id: "anikoto", kind: "zg-provider", repo: ZG_INDEX },
          { id: "archive.org", kind: "rest", base: "https://archive.org" }
        ],
        providersVersion: 1
      });
    }
    if (route.startsWith("/provider-code/")) {
      const id = route.split("/").pop();
      const code = await (await fetch(`${ZG_BASE}providers/${id}.js`)).text();
      return { statusCode: 200, headers: { "Content-Type": "text/javascript", "Access-Control-Allow-Origin": "*" }, body: code };
    }
    const crypto2 = await import("crypto");
    const sha = (s) => crypto2.createHash("sha256").update(s).digest("hex");
    const SALT = process.env.INVITE_SALT || "nx-a1b2c3d4e5f6g7h8i9j0k1l2";
    const SECRET = process.env.STAFF_SECRET || "nx-staff-tok-s2";
    const STAFF_HASHES = (process.env.STAFF_HASHES || "ac69cfc6c01bee8cf292457b750e2c14b314832ff4215ef23fc5b38eca92c67a").split(",");
    const SEED_HASHES = ["c88eab1d62adf64cb4ebadce17b8f4069e2e7cd5e8ff9ba31487767664d9f289"];
    const keyHash = (k) => sha(`${k}:${SALT}`);
    const blob = async (name) => (await Promise.resolve().then(() => (init_main(), main_exports))).getStore({
      name,
      siteID: "b19f8392-b12a-451d-94f3-8d64dbefc741",
      token: process.env.NX_BLOBS_TOKEN || ""
    });
    const body = () => {
      try {
        return event.body ? JSON.parse(event.body) : {};
      } catch {
        return {};
      }
    };
    const auth = () => {
      const t = (params.token || (event.headers.authorization || "").replace(/^Bearer /, "")).split(".");
      if (t.length !== 3) return false;
      const [u, exp, sig] = t;
      return Date.now() < +exp && sha(`${u}:${exp}:${SECRET}`) === sig;
    };
    if (route === "/invite/validate") {
      const key = (params.key || "").trim();
      const did = (params.did || "").trim();
      const name = (params.name || "").trim().slice(0, 40);
      const discord = (params.discord || "").trim().slice(0, 40);
      if (!key) return json({ ok: false, error: "key required" }, 400);
      const store = await blob("invites");
      for (const h of SEED_HASHES) await store.set(h, JSON.stringify({ seed: true }));
      const rec = JSON.parse(await store.get(keyHash(key)) || "null");
      if (!rec) return json({ ok: false });
      const isFriend = rec.type === "friend";
      const isAdmin = rec.type === "admin";
      const cap = isFriend ? 2 : isAdmin ? 999 : 3;
      if (did) {
        const dev = await blob("devices");
        const dslot = `devicekeys:${did}`;
        const bound = JSON.parse(await dev.get(dslot) || "null");
        if (bound && bound.keyHash !== keyHash(key)) {
          const abuse = await blob("abuse");
          await abuse.set(did, JSON.stringify({ keys: [.../* @__PURE__ */ new Set([bound.keyHash, keyHash(key)])], at: Date.now() }));
          return json({ ok: false, error: "key_abuse" });
        }
        if (!bound) await dev.set(dslot, JSON.stringify({ keyHash: keyHash(key), since: Date.now() }));
        const slot = `devices:${keyHash(key)}`;
        const d = JSON.parse(await dev.get(slot) || '{"devices":{}}');
        const cutoff = Date.now() - 14 * 864e5;
        d.devices = Object.fromEntries(Object.entries(d.devices).filter(([, t]) => t > cutoff));
        if (!(did in d.devices) && Object.keys(d.devices).length >= cap) {
          return json({ ok: false, error: "max_devices", max: cap });
        }
        d.devices[did] = Date.now();
        await dev.set(slot, JSON.stringify(d));
      }
      const prof = await blob("profiles");
      const pslot = `profile:${sha(key)}`;
      const prof0 = JSON.parse(await prof.get(pslot) || "{}");
      let discordVerified = prof0.discordVerified || false;
      if (discord && (process.env.DISCORD_BOT_TOKEN || "") && (process.env.DISCORD_GUILD_ID || "")) {
        try {
          const r = await fetch(
            `https://discord.com/api/v10/guilds/${process.env.DISCORD_GUILD_ID}/members/search?query=${encodeURIComponent(discord)}&limit=5`,
            { headers: { Authorization: `Bot ${process.env.DISCORD_BOT_TOKEN}` } }
          );
          const ms = r.ok ? await r.json() : [];
          discordVerified = ms.some((m2) => {
            const u = m2.user || {};
            const tag = `${u.username}`;
            return tag === discord || `${tag}#${u.discriminator}` === discord || `${u.username}#${u.discriminator}` === discord;
          });
        } catch {
        }
      }
      if (name || discord) {
        await prof.set(pslot, JSON.stringify({
          name: name || prof0.name || "",
          discord: discord || prof0.discord || "",
          discordVerified,
          firstSeen: prof0.firstSeen || Date.now(),
          lastSeen: Date.now()
        }));
        const vslot = `profile:${keyHash(key)}`;
        const v0 = JSON.parse(await prof.get(vslot) || "{}");
        await prof.set(vslot, JSON.stringify({ ...v0, name: name || v0.name || "", discord: discord || v0.discord || "" }));
      }
      if (!isFriend) {
        const fr = await blob("friendkeys");
        const slot = `friend:${keyHash(key)}`;
        let fk = await fr.get(slot);
        if (!fk) {
          fk = `NX-F-${crypto2.randomBytes(3).toString("hex").toUpperCase()}`;
          await store.set(keyHash(fk), JSON.stringify({ type: "friend", parent: keyHash(key), at: Date.now() }));
          await fr.set(slot, fk);
        }
        return json({ ok: true, type: "member", friendKey: fk, discordVerified });
      }
      if (isAdmin) return json({ ok: true, type: "admin", discordVerified });
      return json({ ok: true, type: "friend", discordVerified });
    }
    if (route === "/presence") {
      const key = (params.key || "").trim();
      const did = (params.did || "").trim();
      if (!key) return json({ ok: false }, 400);
      const dev = await blob("devices");
      const bound = JSON.parse(await dev.get(`devicekeys:${did}`) || "null");
      if (did && !bound) return json({ ok: false, kicked: true });
      const store = await blob("presence");
      await store.set(`${sha(key)}:${did || "dev"}`, JSON.stringify({ lastSeen: Date.now(), kh: keyHash(key) }));
      return json({ ok: true });
    }
    if (route === "/signout") {
      const key = (params.key || "").trim(), did = (params.did || "").trim();
      if (!key || !did) return json({ ok: false }, 400);
      const dev = await blob("devices");
      const slot = `devices:${keyHash(key)}`;
      const d = JSON.parse(await dev.get(slot) || '{"devices":{}}');
      delete d.devices[did];
      await dev.set(slot, JSON.stringify(d));
      await dev.delete(`devicekeys:${did}`);
      const pres = await blob("presence");
      await pres.delete(`${sha(key)}:${did}`);
      return json({ ok: true });
    }
    if (route === "/staff/login") {
      const { u, p } = body();
      if (!u || !p) return json({ ok: false, error: "u/p required" }, 400);
      if (!STAFF_HASHES.includes(sha(`${p}:nx-staff-s1`))) return json({ ok: false }, 403);
      const exp = Date.now() + 6 * 3600 * 1e3;
      return json({ ok: true, user: u, token: `${u}.${exp}.${sha(`${u}:${exp}:${SECRET}`)}` });
    }
    if (route === "/discord/interactions") {
      const pub = process.env.DISCORD_PUBLIC_KEY || "";
      const bot = process.env.DISCORD_BOT_TOKEN || "";
      const guild = process.env.DISCORD_GUILD_ID || "";
      const roleId = process.env.DISCORD_MEMBER_ROLE_ID || "";
      if (!pub) return json({ error: "discord not configured" }, 503);
      const sig = event.headers["x-signature-ed25519"] || "";
      const ts = event.headers["x-signature-timestamp"] || "";
      const raw = event.isBase64Encoded ? Buffer.from(event.body || "", "base64").toString() : event.body || "";
      let valid = false;
      try {
        const spki = Buffer.from(`302a300506032b6570032100${pub}`, "hex");
        valid = crypto2.verify(null, Buffer.from(ts + raw), { key: spki, format: "der", type: "spki" }, Buffer.from(sig, "hex"));
      } catch {
        valid = false;
      }
      if (!valid) return json({ error: "bad signature" }, 401);
      const i = JSON.parse(raw);
      if (i.type === 1) return { statusCode: 200, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type: 1 }) };
      if (i.type === 2 && i.data?.name === "verify") {
        const key = (i.data.options || []).find((o) => o.name === "key")?.value?.trim() || "";
        const userId = i.member?.user?.id || "";
        const tag = i.member?.user ? `${i.member.user.username}` : "";
        const store = await blob("invites");
        const rec = JSON.parse(await store.get(keyHash(key)) || "null");
        if (!rec) return { statusCode: 200, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type: 4, data: { content: "That invite key isn't valid." } }) };
        const prof = await blob("profiles");
        await prof.set(`profile:${keyHash(key)}`, JSON.stringify({ discordId: userId, discordTag: tag, verifiedAt: Date.now() }));
        if (bot && guild && roleId) {
          await fetch(`https://discord.com/api/v10/guilds/${guild}/members/${userId}/roles/${roleId}`, { method: "PUT", headers: { Authorization: `Bot ${bot}` } });
        }
        return { statusCode: 200, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type: 4, data: { content: `Verified \u2014 welcome to Nek\u014DX, ${tag}.` } }) };
      }
      return { statusCode: 200, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type: 4, data: { content: "Unknown command." } }) };
    }
    if (route.startsWith("/admin/")) {
      if (!auth()) return json({ ok: false, error: "staff login required" }, 401);
      if (route === "/admin/members") {
        const store = await blob("presence");
        const { blobs } = await store.list();
        const now = Date.now();
        const prof = await blob("profiles");
        const byKey = {};
        for (const b of blobs) {
          const d = JSON.parse(await store.get(b.key) || "{}");
          const keyPart = b.key.split(":")[0];
          const g = byKey[keyPart] ||= { id: keyPart.slice(0, 12), kh: "", devices: 0, lastSeen: 0, online: false };
          g.kh = d.kh || g.kh;
          g.devices += 1;
          g.lastSeen = Math.max(g.lastSeen, d.lastSeen || 0);
          if (now - (d.lastSeen || 0) < 24e4) g.online = true;
        }
        const groups = await Promise.all(Object.entries(byKey).map(async ([keyPart, g]) => {
          const p = JSON.parse(await prof.get(`profile:${keyPart}`) || "{}");
          const v = g.kh ? JSON.parse(await prof.get(`profile:${g.kh}`) || "{}") : {};
          return { ...g, name: p.name || v.name || "", discord: v.discordTag || p.discord || v.discord || "", discordId: v.discordId || "" };
        }));
        const people = {};
        for (const g of groups) {
          const pid = g.discordId ? `d:${g.discordId}` : g.name ? `n:${g.name.toLowerCase()}` : `k:${g.id}`;
          const p = people[pid] ||= { id: g.id, name: "", discord: "", devices: 0, keys: 0, lastSeen: 0, online: false };
          p.devices += g.devices;
          p.keys += 1;
          p.name = p.name || g.name;
          p.discord = p.discord || g.discord;
          p.lastSeen = Math.max(p.lastSeen, g.lastSeen);
          p.online = p.online || g.online;
        }
        const members = Object.values(people).sort((a, b) => b.online - a.online || b.lastSeen - a.lastSeen);
        return json({ ok: true, members, online: members.filter((m2) => m2.online).length });
      }
      if (route === "/admin/keys") {
        const store = await blob("invites");
        if (route === "/admin/keys" && event.httpMethod === "DELETE") {
          await store.delete(params.hash || "");
          return json({ ok: true });
        }
        if (params.mint) {
          const newKey = `NX-${crypto2.randomBytes(3).toString("hex").toUpperCase()}`;
          await store.set(keyHash(newKey), JSON.stringify({ name: params.mint, at: Date.now() }));
          return json({ ok: true, key: newKey });
        }
        if (params.resetDevices) {
          const dev2 = await blob("devices");
          await dev2.delete(`devices:${params.resetDevices}`);
          return json({ ok: true });
        }
        const { blobs } = await store.list();
        const prof = await blob("profiles");
        const dev = await blob("devices");
        const keys = await Promise.all(blobs.map(async (b) => {
          const dd = JSON.parse(await dev.get(`devices:${b.key}`) || '{"devices":{}}');
          const rec = JSON.parse(await store.get(b.key) || "{}");
          const p = JSON.parse(await prof.get(`profile:${b.key}`) || "{}");
          const n = Object.keys(dd.devices).length;
          return { hash: b.key.slice(0, 10), type: rec.type || "member", name: p.name || rec.name || "", discord: p.discord || "", devices: n, used: n > 0, seed: !!rec.seed };
        }));
        return json({ ok: true, keys, count: keys.length, used: keys.filter((k) => k.used).length, unused: keys.filter((k) => !k.used).length });
      }
      if (route === "/admin/mintadmin") {
        const n = Math.min(parseInt(params.n || "2"), 10);
        const inv = await blob("invites");
        const keys = [];
        for (let i = 0; i < n; i++) {
          const k = `NEKX-ADM-${crypto2.randomBytes(3).toString("hex").toUpperCase()}`;
          await inv.set(keyHash(k), JSON.stringify({ type: "admin", minted: Date.now() }));
          keys.push(k);
        }
        return json({ ok: true, keys });
      }
      if (route === "/admin/mintbulk") {
        const n = Math.min(parseInt(params.n || "50"), 200);
        const inv = await blob("invites"), fr = await blob("friendkeys");
        const fAll = await fr.list();
        for (const b of fAll.blobs) {
          const fk = await fr.get(b.key);
          if (fk) await inv.delete(keyHash(fk));
          await fr.delete(b.key);
        }
        const iAll = await inv.list();
        for (const b of iAll.blobs) {
          const rec = JSON.parse(await inv.get(b.key) || "{}");
          if (rec.type === "friend") await inv.delete(b.key);
        }
        const pairs = [];
        for (let i = 0; i < n; i++) {
          const mk = `NEKX-${crypto2.randomBytes(2).toString("hex").toUpperCase()}-${crypto2.randomBytes(2).toString("hex").toUpperCase()}`;
          const fk = `NX-F-${crypto2.randomBytes(3).toString("hex").toUpperCase()}`;
          await inv.set(keyHash(mk), JSON.stringify({ type: "member", minted: Date.now() }));
          await inv.set(keyHash(fk), JSON.stringify({ type: "friend", parent: keyHash(mk), at: Date.now() }));
          await fr.set(`friend:${keyHash(mk)}`, fk);
          pairs.push({ member: mk, friend: fk });
        }
        return json({ ok: true, count: pairs.length, pairs });
      }
      if (route === "/admin/allkeys") {
        const inv = await blob("invites");
        const fr = await blob("friendkeys");
        const { blobs } = await fr.list();
        const friendKeys = await Promise.all(blobs.map(async (b) => ({ key: await fr.get(b.key), parent: b.key.slice(7, 17), type: "friend" })));
        const seedKeys = (process.env.NEKOX_SEED_KEYS || "NEKX-NEKO-2025").split(",").map((k) => ({ key: k.trim(), type: "member" }));
        return json({ ok: true, keys: [...seedKeys, ...friendKeys] });
      }
      if (route === "/admin/kick") {
        const mid = (params.member || "").trim();
        if (!mid) return json({ ok: false, error: "member required" }, 400);
        const pres = await blob("presence"), dev = await blob("devices");
        const rec = JSON.parse(await pres.get(mid) || "null");
        const kh = rec?.kh, did = mid.split(":")[1];
        if (!kh) return json({ ok: false, error: "member not found" }, 404);
        const dslot = `devices:${kh}`;
        const dd = JSON.parse(await dev.get(dslot) || '{"devices":{}}');
        if (params.all) {
          for (const d of Object.keys(dd.devices)) await dev.delete(`devicekeys:${d}`);
          dd.devices = {};
          const { blobs } = await pres.list({ prefix: `${mid.split(":")[0]}:` });
          for (const b of blobs) await pres.delete(b.key);
        } else {
          delete dd.devices[did];
          await dev.delete(`devicekeys:${did}`);
          await pres.delete(mid);
        }
        await dev.set(dslot, JSON.stringify(dd));
        return json({ ok: true });
      }
      if (route === "/admin/signoutall") {
        const pres = await blob("presence"), dev = await blob("devices"), inv = await blob("invites");
        const { blobs: keys } = await inv.list();
        for (const k of keys) await dev.delete(`devices:${k.key}`);
        const { blobs: dbs } = await dev.list({ prefix: "devicekeys:" });
        for (const b of dbs) await dev.delete(b.key);
        const { blobs: ps } = await pres.list();
        for (const b of ps) await pres.delete(b.key);
        return json({ ok: true });
      }
      if (route === "/admin/abuse") {
        const abuse = await blob("abuse");
        const { blobs } = await abuse.list();
        const flags = await Promise.all(blobs.map(async (b) => ({ did: b.key.slice(0, 10), ...JSON.parse(await abuse.get(b.key) || "{}") })));
        return json({ ok: true, abuse: flags, count: flags.length });
      }
      return json({ ok: true });
    }
    return json({ ok: true, service: "nekomo-nekox" });
  } catch (err) {
    return json({ error: err.message }, 500);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
